<?php
  class FavouriteApp extends ActiveRecord\Model { 
    
  }
?>