<?php
  class RelatedInformation extends ActiveRecord\Model { 
    
  }
?>