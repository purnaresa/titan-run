<?php
  class DeliveryPrice extends ActiveRecord\Model { 
    
  }
?>