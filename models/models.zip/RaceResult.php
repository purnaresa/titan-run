<?php
  class RaceResult extends ActiveRecord\Model { }
?>