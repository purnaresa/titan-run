<?php
  class Admin extends ActiveRecord\Model { 
    
  }
?>