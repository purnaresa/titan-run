<?php
  class Gallery extends ActiveRecord\Model { }
?>