<?php include "views/shared/header.php"; ?>
<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top" style="background-color:#35363A;">
  <?php include "views/shared/home_navigation.php"; ?>
  <section class="title-gallery">
    <div class="container">
      <div class="col-sm-6">
        <ol class="breadcrumb pull-left">
          <li><a href="index.php#download">Preview</a></li>
          <li><a href="galleries">Gallery</a></li>
          <li class="active"><?php echo $year; ?></li>
        </ol>
      </div>
      <div class="col-sm-6">
        <h4 class="pull-right">GALLERY</h4>
      </div>
    </div>
  </section>
  
  <section class="foto-foto">
    <div class="container">
      <div class="row">
        <div class='list-group gallery' id="gallery_photo">
          <?php foreach($galleries as $gallery): ?>
            <div class="col-sm-4 decreasepad">
              <a class="thumbnail fancybox" rel="ligthbox" href="<?php echo $gallery->location.$gallery->name; ?>">
                <img class="img-responsive" alt="<?php echo $gallery->name; ?>" src="<?php echo $gallery->location.$gallery->name; ?>" />
              </a>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </section>

  <script>
    $(document).ready(function () {
      $(".fancybox").fancybox({
        openEffect: "none",
        closeEffect: "none"
      });
    });
  </script>
  <?php include "views/shared/footer.php"; ?>
</body>