<!-- Section Gallery TITAN RUN -->
<section id="download" class="text-center">
  <div class="download-section">
    <div class="container">
      <div class="col-md-6 title-about">
        <!-- <h3>TITAN RUN 2016</h3> -->
        <h2>FOTO GALERI</h2>
      </div>
      <div class="col-lg-12">
        <div id="owl-example" class="owl-carousel photo-prev">
          <?php foreach($galleries as $gallery): ?>
            <div style="alignment-adjust: middle">
              <img src="<?php echo $gallery->thumbnail_location.$gallery->thumbnail; ?>" alt="<?php echo $gallery->name; ?>">
            </div>
          <?php endforeach; ?>
        </div>
        <div>
          <a href="galleries" class="btn btn-register">LIHAT SEMUA</a>
        </div>
        <br/>
        <div class="pull-right hide">
          <a href="upload_image.php" target="_blank">Upload</a>
        </div>
      </div>
    </div>
  </div>
</section>